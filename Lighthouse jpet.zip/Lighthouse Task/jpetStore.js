const fs = require('fs')
const puppeteer = require('puppeteer')
const lighthouse = require('lighthouse');

async function waitTillHTMLRendered(page, timeout = 30000) {
  const checkInterval = 1000;
  const maxChecks = timeout / checkInterval;
  let lastHTMLSize = 0;
  let stableIterations = 0;
  const minStableIterations = 3;

  for (let i = 0; i < maxChecks; i++) {
    let htmlSize = 0;
    try {
      const html = await page.content();
      htmlSize = html.length;
    } catch {
      await new Promise(r => setTimeout(r, checkInterval));
      continue;
    }

    if (htmlSize === lastHTMLSize) {
      stableIterations++;
    } else {
      stableIterations = 0;
    }

    if (stableIterations >= minStableIterations) {
      console.log(`✅ Fully Rendered: ${page.url()}`);
      break;
    }

    lastHTMLSize = htmlSize;
    await new Promise(r => setTimeout(r, checkInterval));
  }
}

async function captureReport() {
	// const browser = await puppeteer.launch({args: ['--allow-no-sandbox-job', '--allow-sandbox-debugging', '--no-sandbox', '--disable-gpu', '--disable-gpu-sandbox', '--display', '--ignore-certificate-errors', '--disable-storage-reset=true']});

    //for docker file running
    const browser = await puppeteer.launch({
        executablePath: process.env.PUPPETEER_EXECUTABLE_PATH,
        headless: true,
        args: ['--no-sandbox', '--disable-setuid-sandbox']
    });

	// const browser = await puppeteer.launch({"headless": false, args: ['--allow-no-sandbox-job', '--allow-sandbox-debugging', '--no-sandbox', '--ignore-certificate-errors', '--disable-storage-reset=true']});
	const page = await browser.newPage();
	const baseURL = "https://petstore.octoperf.com/actions/Catalog.action";
	
	await page.setViewport({"width":1920,"height":1080});
	await page.setDefaultTimeout(15000);
	
    const flow = await lighthouse.startFlow(page, {
		name: 'JPetStore User Flow',
		configContext: {
		  settingsOverrides: {
			throttlingMethod: "simulate",
			screenEmulation: {
			  mobile: false,
			  width: 1920,
			  height: 1080,
			  deviceScaleFactor: 1,
			  disabled: false,
			},
			formFactor: "desktop",
			onlyCategories: ['performance'],
		  },
		},
	});


	//================================SELECTORS================================
	const signIn        = "a[href*='signonForm']";
	const loginUsername = "input[name='username']";
	const loginPassword = "input[name='password']";
	const loginSubmit   = "input[name='signon']";
	const signOff       = "a[href*='signoff']";
    const category      = "a[href*='categoryId=FISH']";
    const viewProduct   = "a[href*='viewProduct']";
    const product       = "a[href*='productId=FI-SW-02']";
    const viewItem      = "a[href*='viewItem']";
    const item          = "a[href*='itemId=EST-3']";
    const addToCart     = "a[href*='addItemToCart']";
    const checkOut      = "a[href*='newOrderForm=']";
    const payment       = "input[name='newOrder']";
    const confirmButton = "a[href*='newOrder=&confirmed=true']";

    //================================ STEP 1: OPEN HOMEPAGE ================================
    await flow.navigate(baseURL, {
		stepName: 'open main page'
		});
  	console.log('Opened homepage');
    await waitTillHTMLRendered(page);

    //================================ STEP 2: CLICK ON SIGNIN ================================
    await flow.startTimespan({ stepName: 'click on sign in' });
    await page.click(signIn);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(loginUsername, { visible: true});
    await flow.endTimespan();
    console.log('Clicked on sign in');

    //================================ STEP 3: ENTER CREDENTIALS AND LOGIN ================================
    const username = "prishika211";
	const password     = "prishika211";

    await flow.startTimespan({ stepName: 'login' });
    await page.click(loginUsername, { clickCount: 3 });
    await page.keyboard.press('Backspace');
    await page.type(loginUsername, username);
    await page.click(loginPassword, { clickCount: 3 });
    await page.keyboard.press('Backspace');
    await page.type(loginPassword, password);
    await page.click(loginSubmit);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(signOff, { visible: true });
    await flow.endTimespan();
    console.log('Login completed');

    //================================ STEP 4: SELECT PET CATEGORY ================================
    await flow.startTimespan({ stepName: 'select pet' });
    await page.click(category);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(viewProduct);
    await flow.endTimespan();
    console.log('Pet category selected');

    //================================ STEP 5: SELECT PRODUCT ================================
    await flow.startTimespan({ stepName: 'select product' });
    await page.click(product);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(viewItem); 
    await flow.endTimespan();
    console.log('Product selected');

    //================================ STEP 6: SELECT ITEM ================================
    await flow.startTimespan({ stepName: 'select item' });
    await page.click(item);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(addToCart); 
    await flow.endTimespan();
    console.log('Item selected');

    //================================ STEP 7: ADD TO CART ================================
    await flow.startTimespan({ stepName: 'add to cart' });
    await page.click(addToCart);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(checkOut); 
    await flow.endTimespan();
    console.log('Item added to cart');

    //================================ STEP 8: PROCEED TO CHECKOUT ================================
    await flow.startTimespan({ stepName: 'proceed to checkout' });
    await page.click(checkOut);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(payment, { visible: true }); 
    await flow.endTimespan();
    console.log('Proceed to checkout');

    //================================ STEP 9: PAYMENT ================================
    await flow.startTimespan({ stepName: 'enter payment details' });
    await page.click(payment);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(confirmButton, { visible: true }); 
    await flow.endTimespan();
    console.log('Payment details entered');

    //================================ STEP 10: CONFIRM ORDER ================================
    await flow.startTimespan({ stepName: 'confirm order' });
    await page.click(confirmButton);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(signOff, { visible: true }); 
    await flow.endTimespan();
    console.log('Order confirmed');

    //================================ STEP 11: SIGN OFF ================================
    await flow.startTimespan({ stepName: 'sign off' });
    await page.click(signOff);
    await waitTillHTMLRendered(page);
    await page.waitForSelector(signIn, { visible: true }); 
    await flow.endTimespan();
    console.log('Signed off successfully');


	//================================REPORTING================================
	const reportPath = __dirname + '/jpetstore-user-flow.report.html';
	//const reportPathJson = __dirname + '/user-flow.report.json';

	const report = await flow.generateReport();
	//const reportJson = JSON.stringify(flow.getFlowResult()).replace(/</g, '\\u003c').replace(/\u2028/g, '\\u2028').replace(/\u2029/g, '\\u2029');
	
	fs.writeFileSync(reportPath, report);
	//fs.writeFileSync(reportPathJson, reportJson);
	
    await browser.close();
}
captureReport();

