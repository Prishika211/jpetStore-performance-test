# 🌐 JPetStore Performance + User Flow Report — Puppeteer + Lighthouse

## 📘 Overview

This script uses **Puppeteer** and **Lighthouse User Flow** to automate and measure **front-end performance** for the [JPetStore demo application](https://petstore.octoperf.com).  
It simulates a real user journey, captures screenshots, and generates detailed **Lighthouse HTML reports** for each step.

---

## ⚙️ Tech Stack

- **Node.js** (v18+)
- **Puppeteer-Core** (Headless Chrome automation)
- **Chrome Launcher**
- **Lighthouse**
- **Lighthouse User-Flow API**

---

## 🧩 Automated User Flow

| Step | Description | Verification |
|------|--------------|---------------|
| 1️⃣ | Open Home Page | Confirm full render of `Catalog.action` |
| 2️⃣ | Click “Sign In” | Verify login page rendered |
| 3️⃣ | Enter Credentials | Username: `prishika211` / Password: `j2ee` |
| 4️⃣ | Wait for “Sign Out” link | Confirms successful login |
| 5️⃣ | Navigate to a Category | e.g., Fish, Dogs, Cats |
| 6️⃣ | Select a Product | Example: Angelfish |
| 7️⃣ | Open Item Page | Verify `itemId` and product details |
| 8️⃣ | Add to Cart | Confirm item in cart table |
| 9️⃣ | Capture Lighthouse Report | Save HTML report and screenshots |

---
## ▶️ Setup & Execution

### 1. 🧩 Install Dependencies

Run the following command to install all required packages:

```bash
npm install puppeteer-core lighthouse chrome-launcher
```
---
### 2. 🚀 Run Script

Execute the JPetStore performance flow script:

```bash
node jpetStore.js
```
---
### 3. 📦 Output

After successful execution, the following files and artifacts will be generated:

| Output File                       | Description                                                                 |
|-----------------------------------|------------------------------------------------------------------------------|
| `jpetstore-user-flow.report.html` | Complete Lighthouse flow report with step-by-step performance metrics       |
| Console Logs                      | Real-time logs showing navigation, element waits, and action confirmations |



