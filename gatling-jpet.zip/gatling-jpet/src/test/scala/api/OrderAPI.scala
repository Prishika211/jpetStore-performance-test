package api

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._
import scenarios.JPetStoreScenario.userFeeder

object OrderAPI {
  def enterPaymentDetails(): ChainBuilder = {
    feed(userFeeder)
      .exec { session =>
        println("===== Payment Feeder Data =====")
        println(s"Card Number: ${session("p_cred").as[String]}")
        println(s"Expiry: ${session("p_expiry").as[String]}")
        println(s"Name: ${session("p_firstName").as[String]} ${session("p_lastName").as[String]}")
        println(s"Address: ${session("p_add1").as[String]}, ${session("p_city").as[String]}")
        println("===============================")
        session
      }
      .exec(
        http("Enter Payment Details")
          .post("/Order.action")
          .formParam("order.cardType", "Visa")
          .formParam("order.creditCard", "${p_cred}")
          .formParam("order.expiryDate", "${p_expiry}")
          .formParam("order.billToFirstName", "${p_firstName}")
          .formParam("order.billToLastName", "${p_lastName}")
          .formParam("order.billAddress1", "${p_add1}")
          .formParam("order.billAddress2", "${p_add2}")
          .formParam("order.billCity", "${p_city}")
          .formParam("order.billState", "${p_state}")
          .formParam("order.billZip", "${p_zip}")
          .formParam("order.billCountry", "${p_country}")
          .formParam("newOrder", "Continue")
          .check(status.is(200))
    )
  }

  def confirmOrder(): ChainBuilder = {
    exec(
      http("Confirm Order")
        .get("/Order.action?newOrder=&confirmed=true")
        .check(status.is(200))
    )
  }

  def signOff(): ChainBuilder = {
    exec(
      http("Sign Off")
        .get("/Account.action?signoff=")
        .check(status.is(302))
    )
  }
}
