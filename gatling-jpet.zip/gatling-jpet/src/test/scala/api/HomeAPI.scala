package api

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._

object HomeAPI {
  def openHome(): ChainBuilder = {
    exec(
      http("Open Home Page")
        .get("/Catalog.action")
        .check(status.is(200))
        .check(regex("""categoryId=([A-Za-z0-9-]+)""").findAll.saveAs("categoryIds"))
    )
      .exec { session =>
        val ids = session("categoryIds").asOption[List[String]].getOrElse(Nil)

        val randomId =
          if (ids.nonEmpty) ids(scala.util.Random.nextInt(ids.length))
          else "FISH"

        println(s"✅ Randomly selected categoryId: $randomId")

        session.set("categoryId", randomId)
      }
  }

  def openSignIn(): ChainBuilder = {
    exec(
      http("Open Sign In Page")
        .get("/Account.action?signonForm=")
        .check(status.is(200))
    )
  }
}
