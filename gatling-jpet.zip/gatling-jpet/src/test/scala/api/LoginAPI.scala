package api

import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._

object LoginAPI {
  def login(username: String = "j2ee", password: String = "j2ee"): ChainBuilder  = {
    exec(http("Login Request")
      .post("/Account.action")
      .formParam("username", username)
      .formParam("password", password)
      .formParam("signon", "Login")
      .check(status.is(302)))
  }
}
