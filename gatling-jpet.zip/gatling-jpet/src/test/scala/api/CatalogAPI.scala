package api

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._

object CatalogAPI {
  def selectPet(): ChainBuilder = {
    exec(
      http("Select Pet - ${categoryId}")
        .get("/Catalog.action?viewCategory=&categoryId=${categoryId}")
        .check(status.is(200))
        .check(regex("""productId=([A-Za-z0-9-]+)""").findAll.saveAs("productIds"))
    )
      .exec { session =>
        val ids = session("productIds").asOption[List[String]].getOrElse(Nil)
        val randomId =
          if (ids.nonEmpty) ids(scala.util.Random.nextInt(ids.length))
          else "FI-SW-01"

        println(s"✅ Randomly selected productId: $randomId")
        session.set("productId", randomId)
      }
  }

  def selectProduct(): ChainBuilder = {
    exec(
      http("Select Product - ${productId}")
        .get("/Catalog.action?viewProduct=&productId=${productId}")
        .check(status.is(200))
        .check(regex("""itemId=([A-Za-z0-9-]+)""").findAll.saveAs("itemIds"))
    )
      .exec { session =>
        val items = session("itemIds").asOption[List[String]].getOrElse(Nil)
        val randomItem =
          if (items.nonEmpty) items(scala.util.Random.nextInt(items.length))
          else "EST-1"
        println(s"Captured itemIds: $items, Selected itemId: $randomItem")
        session.set("itemId", randomItem)
      }
  }

  def selectItem(): ChainBuilder = {
    exec(
      http("Select Item - ${itemId}")
        .get("/Catalog.action?viewItem=&itemId=${itemId}")
        .check(status.is(200))
        .check(regex("""workingItemId=([A-Za-z0-9-]+)""").findAll.saveAs("workingItemIds"))
    )
      .exec { session =>
        val items = session("workingItemIds").asOption[List[String]].getOrElse(Nil)
        val randomWorkingId =
          if (items.nonEmpty) items(scala.util.Random.nextInt(items.length))
          else session("itemId").asOption[String].getOrElse("EST-1")
        println(s"Captured workingItemIds: $items, Selected workingItemId: $randomWorkingId")
        session.set("workingItemId", randomWorkingId)
      }
  }

}
