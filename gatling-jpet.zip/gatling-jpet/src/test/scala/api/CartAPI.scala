package api

import io.gatling.core.Predef._
import io.gatling.core.structure.ChainBuilder
import io.gatling.http.Predef._

object CartAPI {
  def addItemToCart(): ChainBuilder = {
    exec(
      http("Add Item to Cart - ${workingItemId}")
        .get("/Cart.action?addItemToCart=&workingItemId=${workingItemId}")
        .check(status.is(200))
    )
      .exec { session =>
        println(s"Added itemId: ${session("workingItemId").asOption[String].getOrElse("N/A")} to cart")
        session
      }
  }

  def proceedToCheckout(): ChainBuilder = {
    exec(
      http("Proceed to Checkout")
        .get("/Order.action?newOrderForm=")
        .check(status.is(200))
    )
  }
}
