package simulations

import config.BaseHelpers.httpProtocol
import io.gatling.core.Predef._
import scenarios.JPetStoreScenario.scnJPetStoreFullFlow

// mvn gatling:test
// mvn clean gatling:test -Dgatling.simulationClass = simulations.JpetStoreSimulation
// mvn clean gatling:test -DFullFlowUsers=100
class JpetStoreSimulation extends Simulation{
  setUp(
    scnJPetStoreFullFlow.inject(atOnceUsers(System.getProperty("FullFlowUsers", "100").toInt)),
  ).protocols(httpProtocol)
}
