package scenarios

import config.BaseHelpers.thinkTimer
import io.gatling.core.Predef._
import io.gatling.core.structure._
import io.gatling.http.Predef._

object JPetStoreScenario {
  val userFeeder = csv("feeders/SC01_JpetParamter.csv").circular

  def scnJPetStoreFullFlow: ScenarioBuilder = {
    scenario("JPetStore Full Flow")
      .feed(userFeeder)
      .exec(flushHttpCache)
      .exec(flushCookieJar)
      .exitBlockOnFail(
        group("01_HomePage"){
          exec(api.HomeAPI.openHome())
            .exec(thinkTimer())
        }
          .group("02_ClickOnSignIn") {
            exec(api.HomeAPI.openSignIn())
              .exec(thinkTimer())
          }
          .group("03_EnterCredentialsAndLogin"){
            exec(api.LoginAPI.login("${p_username}", "${p_password}"))
              .exec(thinkTimer())
          }
          .group("04_SelectPet"){
            exec(api.CatalogAPI.selectPet())
              .exec(thinkTimer())
          }
          .group("05_SelectProduct"){
            exec(api.CatalogAPI.selectProduct()
              .exec(thinkTimer()))
          }
          .group("06_SelectItem"){
            exec(api.CatalogAPI.selectItem())
              .exec(thinkTimer())
          }
          .group("07_AddToCart"){
            exec(api.CartAPI.addItemToCart())
              .exec(thinkTimer())
          }
          .group("08_ProceedToCheckout"){
            exec(api.CartAPI.proceedToCheckout())
              .exec(thinkTimer())
          }
          .group("09_Payment"){
            exec(api.OrderAPI.enterPaymentDetails())
              .exec(thinkTimer())
          }
          .group("10_Confirm"){
            exec(api.OrderAPI.confirmOrder())
              .exec(thinkTimer())
          }
          .group("11_SignOff"){
            exec(api.OrderAPI.signOff())
              .exec(thinkTimer())
          }
      )
  }

}
